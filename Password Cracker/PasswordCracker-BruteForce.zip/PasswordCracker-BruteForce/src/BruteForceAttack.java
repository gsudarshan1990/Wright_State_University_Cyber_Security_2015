
/*
 * Basic code provided by the @author lingg
 * The following is the extended code to crack the password by BruteForceAttack Method
 */
import java.io.File;
import java.util.zip.ZipException;

import de.idyl.winzipaes.AesZipFileDecrypter;
import de.idyl.winzipaes.AesZipFileEncrypter;
import de.idyl.winzipaes.impl.AESDecrypter;
import de.idyl.winzipaes.impl.AESDecrypterBC;
import de.idyl.winzipaes.impl.AESEncrypter;
import de.idyl.winzipaes.impl.AESEncrypterBC;
import de.idyl.winzipaes.impl.ExtZipEntry;
public class BruteForceAttack {
	
	public static void encrypt(String inputFilename, String zipFilename, String password) 
			throws Exception {
				
        AESEncrypter encrypter = new AESEncrypterBC();
        AESEncrypter encrypter2 = new AESEncrypterBC();
        
        AesZipFileEncrypter.zipAndEncrypt(
        		new File(inputFilename), new File(zipFilename), password, encrypter);
	}

	public static void decrypt(String zipFilename, String outputFilename, String password) 
			throws Exception {
		
        AESDecrypter decrypter = new AESDecrypterBC();
        
        AesZipFileDecrypter dec = new AesZipFileDecrypter(new File(zipFilename), decrypter);
        ExtZipEntry entry = dec.getEntryList().get(0); // assumes only one item is in the zip file
        dec.extractEntry(entry, new File(outputFilename), password);
        dec.close();
        System.out.println("password is:"+password);
        System.exit(0);
	}
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws Exception{
        // TODO code application logic here
    // encrypt("test.txt", "test.zip", "abcd");

  
		String alphabet = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
		
		char[] value=alphabet.toCharArray();
		
		 int len; //Length of the password
		 
		 System.out.println("Brute force method is carried out for password length between 4 and 15");
		 
		 int minlen=4; //Minimum length of the password
		 
		 int maxlen=15; // Maximum length of the password
		 String pass="";
		 
		 int i,j,k;
	for(len=minlen;len<=maxlen;len++)
	{	
		int[] flag=new int[len]; //Declaring the array which indicates the length of the password
	//	Carrying out the Brute force attack 
	// 	// Checking the condition to carry out the BruteForce till  the  last value(flag[0]<61) since password contains lowercase letters ,uppercase letters and numericals and total count  of letters is 62
		while(flag[0]<value.length)
		{
			pass="";
			// To obtain a password of certain length i.e if length 5 password will be abcde or aaaaa		
			
			for(k=0;k<len;k++)
			{
				pass=pass+value[flag[k]]; 
			}
			flag[len-1]++; //Obtaining the next value for password, by moving to next character in value array , initially increment only the last letter of the password.
			
			
			try
			{
				decrypt("test.zip", "test2.txt", pass);
			}
			catch(ZipException ze)
			{
				
			}
			
			// Increment to next position once end value at a certain position(e.g if aa9 is reached then moving to ab0) in password has been reached 
			for(i=len-1;i>0;i--)
			{
				if(flag[i]>value.length-1)
				{
					flag[i-1]++; //By shifting 1 position to the left of the password and incrementing to next value.
					flag[i]=0;// Once last value of a certain position further no changes are made to that position
				}
			}
		}
	}
	

	}

}
