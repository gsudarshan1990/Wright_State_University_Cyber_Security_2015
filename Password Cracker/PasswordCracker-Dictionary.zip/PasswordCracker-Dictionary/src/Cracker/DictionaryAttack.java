
/*
 * Basic code provided by the @author lingg
 * The following is the extended code to crack the password by Dictionary Attack
 */

package Cracker;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.Reader;
import java.util.zip.ZipException;

import de.idyl.winzipaes.AesZipFileDecrypter;
import de.idyl.winzipaes.AesZipFileEncrypter;
import de.idyl.winzipaes.impl.AESDecrypter;
import de.idyl.winzipaes.impl.AESDecrypterBC;
import de.idyl.winzipaes.impl.AESEncrypter;
import de.idyl.winzipaes.impl.AESEncrypterBC;
import de.idyl.winzipaes.impl.ExtZipEntry;

public class DictionaryAttack {
	
	public static void encrypt(String inputFilename, String zipFilename, String password) 
			throws Exception {
				
        AESEncrypter encrypter = new AESEncrypterBC();
        AESEncrypter encrypter2 = new AESEncrypterBC();
        
        AesZipFileEncrypter.zipAndEncrypt(
        		new File(inputFilename), new File(zipFilename), password, encrypter);
	}

	public static void decrypt(String zipFilename, String outputFilename, String password) 
			throws Exception {
		
        AESDecrypter decrypter = new AESDecrypterBC();
        
        AesZipFileDecrypter dec = new AesZipFileDecrypter(new File(zipFilename), decrypter);
        ExtZipEntry entry = dec.getEntryList().get(0); // assumes only one item is in the zip file
        dec.extractEntry(entry, new File(outputFilename), password);
        //When appropriate password is used ZipException won't be raised hence execution will be in this function 
        dec.close();
        //Printing the password which is used to decrypt the file
        System.out.println("Password is :"+password);
        //Exiting from the program once the password is printed.
        System.exit(0);
	}
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws Exception{
        // TODO code application logic here
     // encrypt("test.txt", "test.zip", "joyce");

      
      
    //Creating the instance of the file blink.txt and object name is file
		File file=new File("blink.txt");
		
		BufferedReader reader; // To read text from input stream 
		
		try {
			FileReader fr=new FileReader(file); // To read contents from file
			reader=new BufferedReader(fr); 
			try {
				//reads the line of the text and until the last line
				while(reader.readLine()!=null)
				{
					try {
						// Trying to decrypt the file using the password obtained from Dictionary
						try
				    	{
				    	   	decrypt("test.zip", "test2.txt", reader.readLine()); 
				    	}
						//When wrong password is used ZipException is created and which is handled
				    	catch(ZipException ze)
				    	{
				    		
				    	}
						
					}
					//Handling IO Exception 
					catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
				//Handling IO Exception
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			//Handing FileNotFoundException
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	
	}

}
